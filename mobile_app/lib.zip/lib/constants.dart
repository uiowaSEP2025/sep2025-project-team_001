class ApiConfig {
  static const String baseUrl = 'http://localhost:8000';
}
